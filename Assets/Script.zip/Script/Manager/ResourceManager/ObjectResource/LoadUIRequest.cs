﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.U2D;
using UnityEngine.UI;

public class LoadUIRequest : LoadObjectRequest
{
    string[] pathList;
    HashSet<string> currNeedLoadSet = new HashSet<string>();
    private string path;

    public LoadUIRequest(string path)
    {
        this.path = path;
    }

    public bool CheckFinish() 
    {
        
       return 0 == currNeedLoadSet.Count; 
    }

   public void Finish()
   {

   }

   public void Release()
   {
       for (int i = 0; i < this.pathList.Length; i++)
       {
           var path = this.pathList[i];
           //ResourceManager.Instance.ReturnObject<GameObject>(path,);
       }
    
   }

   public void Start(string[] pathList)
   {
       this.pathList = pathList;
       //这种加载组可以再抽一层
       for (int i = 0; i < pathList.Length; i++)
       {
           var path = pathList[i];
           currNeedLoadSet.Add(path);
           ResourceManager.Instance.GetObject<GameObject>(path, (gameObject)=>
           {
               //gameObject.transform.SetParent(this.uiRoot, false);
               //T t = new T();
               //t.Init(gameObject, uiConfigInfo.path);
               //uiCacheDic.Add(t.GetType(), t);
               //finishCallback?.Invoke(t);
               this.OnGetFinish(path, gameObject);
           });
       }
   }

    public void Start()
    {
        throw new NotImplementedException();
    }

    private void OnGetFinish(string path, GameObject gameObject)
   {
       if (currNeedLoadSet.Contains(path))
       {
           currNeedLoadSet.Remove(path);


       }
       else
       {
           Logx.LogzError("the currPath is not correct : " + path);
       }
   }

}