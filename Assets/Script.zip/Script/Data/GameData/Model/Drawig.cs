﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GS2GC;

namespace DataModel
{
    public class Drawing
    {
        //public int SN;
        //public int id;
        //public Config.DrawingConfig config;

        //Drawing()
        //{

        //}

        //public static Drawing Create(int SN, int id)
        //{
        //    var info = new Drawing()
        //    {
        //        SN = SN,
        //        id = id,
        //        config = Config.ConfigManager.Instance.GetBySN<Config.DrawingConfig>(SN)
        //    };

        //    return info;
        //}

        //public static Drawing Create(GS2GC.Drawing drawing)
        //{
        //    var info = Drawing.Create(drawing.SN, drawing.Id);
        //    return info;
        //}
    }

}

