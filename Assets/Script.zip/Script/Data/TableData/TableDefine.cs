/*
 * generate by tool
*/
using System;
using System.Collections.Generic;
using System.Collections;


//UI 资源 Id 枚举 
public enum UIResIds
{
	
    LoginUI = 1000000000,
    LobbyUI = 1000000001,
    HeroListUI = 1000000002,
    MateMainUI = 1000000003,
    CombatUI = 1000000004,
    LoadingUI = 1000000005,
}
