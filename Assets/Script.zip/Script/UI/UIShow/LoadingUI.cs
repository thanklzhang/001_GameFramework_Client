﻿using GameModelData;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LoadingUI : BaseUI
{
    //public override void Init()
    //{
    //    this.resId = UIResIds.LoadingUI;
    //}

    //public override void LoadFinish(UIContext context)
    //{
    //    base.LoadFinish(context);


    //    //openHeroListBtn = root.Find("heroListBtn").GetComponent<Button>();
    //    //openMateBtn = root.Find("mateBtn").GetComponent<Button>();
    //    //openHeroListBtn.onClick.AddListener(() =>
    //    //{
    //    //    UIManager.Instance.ShowUI<HeroListUI>();
    //    //});
    //    //openHeroListBtn.gameObject.SetActive(false);

    //    //openMateBtn.onClick.AddListener(() =>
    //    //{
    //    //    UIManager.Instance.ShowUI<MateMainUI>();
    //    //});
    //}

    //public override void Show()
    //{
    //    base.Show();
    //    //EventManager.AddListener<bool>((int)GameEvent.ConnectGateServerResult, ConnectGateServerResult);

    //    //EventManager.AddListener<bool>((int)GameEvent.SyncPlayerBaseInfo, SyncPlayerBaseInfo);
    //}

    //public override void Hide()
    //{
    //    base.Hide();
    //    //EventManager.RemoveListener<bool>((int)GameEvent.ConnectGateServerResult, ConnectGateServerResult);
    //    //EventManager.RemoveListener<bool>((int)GameEvent.SyncPlayerBaseInfo, SyncPlayerBaseInfo);
    //}

    ////Button openHeroListBtn;
    ////Button openMateBtn;
}
