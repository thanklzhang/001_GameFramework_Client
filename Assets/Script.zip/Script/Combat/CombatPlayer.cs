﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FixedPointy;
using NetCommon;
using UnityEngine;

public class CombatPlayer
{
    public int userId;
    public int seat;
    public int team;
    public Dictionary<int, CombatEntity> entityDic;//guid 索引

   
}


