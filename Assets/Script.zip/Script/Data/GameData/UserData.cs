﻿//using System;
//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using System.IO;
//using System.Linq;
//using UnityEngine.UI;

//public class UserData
//{
//    private static UserData instance;
//    public static UserData Instance
//    {
//        get
//        {
//            if (null == instance)
//            {
//                instance = new UserData();
//            }
//            return instance;
//        }
//    }

//    public string account;
//    public string userId;
//    public string token;
//}

