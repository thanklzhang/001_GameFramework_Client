﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameData
{
    public class Hero
    {
        public int id;
        public int level;
        public Config.HeroInfo config;
    }
}


