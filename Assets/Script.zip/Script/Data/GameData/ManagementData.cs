﻿using DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameModelData
{
    //public enum ManagementState
    //{
    //    Idle,
    //    Doing,
    //    Finish,
    //    Cooldown
    //}

    //public class ManagementData : Singleton<ManagementData>
    //{
    //    public ManagementState state;// 0-可生产 1-生产中 2-完成 3-冷却中 
    //    public int canUseMaxBenchNum;
    //    public long lastStartTime;
    //    public long lastFinishTime;
     

    //    public void SetManagementInfo(GS2GC.ManagementInfo managementInfo)
    //    {
    //        state = (ManagementState)managementInfo.State;
    //        lastStartTime = managementInfo.LastStartTime;
    //        lastFinishTime = managementInfo.LastFinishTime;
    //        canUseMaxBenchNum = managementInfo.CanUseMaxBenchNum;
         
    //    }

    //}
}
