﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.U2D;
using UnityEngine.UI;
public class PoolObj
{
    public int id;
    public UnityEngine.Object obj;

    public bool isUsing;

    internal bool IsUsing()
    {
        return isUsing;
    }

    internal UnityEngine.Object GetObj()
    {
        return obj;
    }
}
public class ObjectPool
{
    public UnityEngine.Object assetObj;
    public Dictionary<int, PoolObj> objectDic = new Dictionary<int, PoolObj>();
    bool isLoadingAsset = false;
    string path;
    Action<UnityEngine.Object> getObjCallback;
    internal void GetObject(Action<UnityEngine.Object> callback)
    {
        if (null == assetObj)
        {
            //这里这 loadAsset 一次 ，防止同时多次 LoadAsset 调用造成 ab 计数错误

            //不过如果都是走池子的话 那么 LoadAsset 多次实际上也没问题
            //因为如果在需要清理的时候 该类型的obj 都是未使用状态 即使 asset 引用 > 1 那么也可以减少到 0 并清理 objs
            if (isLoadingAsset)
            {
                //正在加载
                getObjCallback += callback;
            }
            else
            {
                isLoadingAsset = true;
                getObjCallback = callback;
                AssetManager.Instance.Load(path, (asset) =>
                {
                    this.OnAssetLoadFinish(asset);
                });
            }
        }
        else
        {
            //有 asset 直接取 obj
            var poolObj = GetCachePoolObj();
            var obj = poolObj.GetObj();
            callback?.Invoke(obj);
        }

    }

    public bool IsGameObject()
    {
        //TODO : 根据 path 来进行断定是否是 GameObject
        return true;
    }

    public PoolObj GetCachePoolObj()
    {
        PoolObj poolObj = null;
        var isGo = IsGameObject();

        if (isGo)
        {
            //有 asset 直接取 obj
            foreach (var item in objectDic)
            {
                if (item.Value.IsUsing())
                {
                    continue;
                }

                poolObj = item.Value;
            }
            if (null == poolObj)
            {
                //如果都在使用 那么创建新的 Object(目前没有上限 之后会有上限)
                poolObj = CreateNew();
            }
        }
        else
        {
            //由于是引用 所以第一个就是
            foreach (var item in objectDic)
            {
                poolObj = item.Value;
            }

            if (null == poolObj)
            {
                //如果都在使用 那么创建新的 Object(目前没有上限 之后会有上限)
                poolObj = CreateNew();
            }
        }
        return poolObj;
    }

    public PoolObj CreateNew()
    {
        //path
        UnityEngine.Object obj = null;
        var isGo = IsGameObject();
       
        PoolObj newPoolObj = null;
        if (isGo)
        {
            obj = GameObject.Instantiate(this.assetObj) as GameObject;
            newPoolObj = new PoolObj();
            newPoolObj.id = obj.GetInstanceID();
            newPoolObj.obj = obj;
            newPoolObj.isUsing = true;
            objectDic.Add(newPoolObj.id, newPoolObj);
        }
        else
        {
            obj = this.assetObj;
            if (!objectDic.ContainsKey(obj.GetInstanceID()))
            {
                newPoolObj = new PoolObj();
                newPoolObj.id = obj.GetInstanceID();
                newPoolObj.obj = obj;
                newPoolObj.isUsing = true;
                objectDic.Add(newPoolObj.id, newPoolObj);
            }
            else
            {
                newPoolObj = objectDic[obj.GetInstanceID()];
            }
        }

        return newPoolObj;
    }

    public void OnAssetLoadFinish(UnityEngine.Object asset)
    {
        var poolObj = GetCachePoolObj();
        var obj = poolObj.GetObj();
        getObjCallback?.Invoke(obj);
    }
}
public class ObjectPoolGroup
{
    public Dictionary<string, ObjectPool> objectPoolDic = new Dictionary<string, ObjectPool>();

    internal void GetObject(string path, Action<UnityEngine.Object> callback)
    {
        ObjectPool pool = null;
        if (objectPoolDic.ContainsKey(path))
        {
            pool = objectPoolDic[path];
        }
        else
        {
            pool = new ObjectPool();
            objectPoolDic.Add(path, pool);
        }

        pool.GetObject(callback);
    }
}
public class ObjectPoolManager : Singleton<ObjectPoolManager>
{
    //gameObject texture sprite material
    public Dictionary<Type, ObjectPoolGroup> objectPoolGroupDic = new Dictionary<Type, ObjectPoolGroup>();

    public void GetObject<T>(string path, Action<UnityEngine.Object> callback)
    {
        var type = typeof(T);
        ObjectPoolGroup group = null;
        if (objectPoolGroupDic.ContainsKey(type))
        {
            group = objectPoolGroupDic[type];
        }
        else
        {
            group = new ObjectPoolGroup();
            objectPoolGroupDic.Add(type, group);
        }

        group.GetObject(path, callback);

    }

    public void ReturnObject<T>(string path, T obj)
    {

    }

    public void Release()
    {
        //清除都没在使用的 poolObj
    }
}